#include "types.h"
#include "user.h"

int main()
{
	// Creating 4 processes, assigning priorities
	int a = fork();
	int b = fork();
	// Different processes execute in different if blocks
	if(a == 0 && b == 0)
	{
		setPriority(5);
		printf(2,"Child Child\n");
	}

	if(a == 0 && b > 0)
	{
		setPriority(3);
		printf(2,"Child Parent\n");
		wait();
	}
	if(a > 0 && b == 0)
	{
		setPriority(6);
		printf(2, "Parent Child\n");
		wait();
	}
	else if(a > 0 && b > 0)
	{
		setPriority(9);
		printf(2,"Parent Parent\n");
		wait();
		wait();
	}

	exit();
}