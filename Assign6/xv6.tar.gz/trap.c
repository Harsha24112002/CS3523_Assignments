#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "x86.h"
#include "traps.h"
#include "spinlock.h"

// Interrupt descriptor table (shared by all CPUs).
struct gatedesc idt[256];
extern uint vectors[];  // in vectors.S: array of 256 entry pointers
struct spinlock tickslock;
uint ticks;

// Copied the code of walkpgdir from vm.c which is used in page fault handler
pte_t * walkpgdir(pde_t *pgdir, const void *va, int alloc)
{
  pde_t *pde;
  pte_t *pgtab;

  pde = &pgdir[PDX(va)];
  if(*pde & PTE_P){
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
  } else {
    if(!alloc || (pgtab = (pte_t*)kalloc()) == 0)
      return 0;
    // Make sure all those PTE_P bits are zero.
    memset(pgtab, 0, PGSIZE);
    // The permissions here are overly generous, but they can
    // be further restricted by the permissions in the page table
    // entries, if necessary.
    *pde = V2P(pgtab) | PTE_P | PTE_W | PTE_U;
  }
  return &pgtab[PTX(va)];
}
/**
 * @brief handles the page fault 
 * It creates a new physical page(frame) and maps it to the virtual address corresponding to the pagefault,
 * (the code is almost similar to that in mappages, except that here we allocate only a single page)
 * @return int 0 if error occured in allocating frame or mapping. 1 if successfully mapped 
 */
int pagefault_handler()
{
  // Allocating a new frame
  char* new_frame = kalloc();
  if(new_frame == 0)
  {
    cprintf("pagefault handler: insufficient memory!\n");
    return 0;
  }
  // Virtual address which caused the page fault
  char* va = (char*)PGROUNDDOWN(rcr2());
  // Initializing the new_frame entries to 0 (To get rid of garbage values)
  memset(new_frame,0,PGSIZE);
  // The page table entry to be added
  pte_t* pte;
  // Implemented code similar to mappages() function in vm.c
  // Using the walkpgdir() function defined above (same as that in vm.c)
  if((pte = walkpgdir(myproc()->pgdir, va, 1)) == 0)
  {
    cprintf("pagefault handler: insufficient memory 2!\n");
    kfree(new_frame);
    return 0;
  }
  // If already existed entry, raise panic as it is remap
  if(*pte & PTE_P)
     panic("remap");

  // Mapping the new frame to virtual address and giving permissions.
  *pte = V2P(new_frame) | PTE_W | PTE_U | PTE_P;
  
  return 1;
}
void
tvinit(void)
{
  int i;

  for(i = 0; i < 256; i++)
    SETGATE(idt[i], 0, SEG_KCODE<<3, vectors[i], 0);
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);

  initlock(&tickslock, "time");
}

void
idtinit(void)
{
  lidt(idt, sizeof(idt));
}

//PAGEBREAK: 41
void
trap(struct trapframe *tf)
{
  if(tf->trapno == T_SYSCALL){
    if(myproc()->killed)
      exit();
    myproc()->tf = tf;
    syscall();
    if(myproc()->killed)
      exit();
    return;
  }

  switch(tf->trapno){
  case T_IRQ0 + IRQ_TIMER:
    if(cpuid() == 0){
      acquire(&tickslock);
      ticks++;
      wakeup(&ticks);
      release(&tickslock);
    }
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_IDE:
    ideintr();
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_IDE+1:
    // Bochs generates spurious IDE1 interrupts.
    break;
  case T_IRQ0 + IRQ_KBD:
    kbdintr();
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_COM1:
    uartintr();
    lapiceoi();
    break;
  case T_IRQ0 + 7:
  case T_IRQ0 + IRQ_SPURIOUS:
    cprintf("cpu%d: spurious interrupt at %x:%x\n",
            cpuid(), tf->cs, tf->eip);
    lapiceoi();
    break;
  case T_PGFLT:
      // If the accessed location is in process's memory
      // 0 < address < sz
      if(myproc()->sz > rcr2() && rcr2() > 0)
      {
        cprintf("page fault occurred, doing demand paing for address: %p\n", rcr2());
        // Handle the page fault
        if(pagefault_handler() == 0)
        {
          myproc()->killed = 1;
        }   
      }
      else
      {
        cprintf("Process accessing out of memory!\n");
        myproc()->killed = 1;
      }
      break;
  //PAGEBREAK: 13
  default:
    if(myproc() == 0 || (tf->cs&3) == 0){
      // In kernel, it must be our mistake.
      cprintf("unexpected trap %d from cpu %d eip %x (cr2=0x%x)\n",
              tf->trapno, cpuid(), tf->eip, rcr2());
      panic("trap");
    }
    // In user space, assume process misbehaved.
    cprintf("pid %d %s: trap %d err %d on cpu %d "
            "eip 0x%x addr 0x%x--kill proc\n",
            myproc()->pid, myproc()->name, tf->trapno,
            tf->err, cpuid(), tf->eip, rcr2());
            myproc()->killed = 1;
  }

  // Force process exit if it has been killed and is in user space.
  // (If it is still executing in the kernel, let it keep running
  // until it gets to the regular system call return.)
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
    exit();

  // Force process to give up CPU on clock tick.
  // If interrupts were on while locks held, would need to check nlock.
  if(myproc() && myproc()->state == RUNNING &&
     tf->trapno == T_IRQ0+IRQ_TIMER)
    yield();

  // Check if the process has been killed since we yielded
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
    exit();
}
