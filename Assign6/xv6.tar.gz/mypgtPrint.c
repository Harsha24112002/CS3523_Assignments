#include "types.h"
#include "user.h"
// GLobal array 
// int arr[10000] 
int main()
{

	// Local array
	// int arr[10000];
	// for(int i=0;i<10000;i++)
	// {
	// 	arr[i]  = i;
	// }
	
	// printf(1,"%d\n",arr[0]);
	
	pgtPrint();
	exit();
}