#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

int sys_pgtPrint(void)
{
  // myproc()->pgdir gives the current process page directory
  pde_t *currentproc_pgdir = myproc()->pgdir;
  // Each pgdir contains adresses of page tables and each pagetable contains the physical
  // page number
  // Hence using the current process page directory, we go through all the entries (2^10)
  // to access all page tables.
  for(int i=0;i<NPDENTRIES;i++)
  {
    // Checking if the page table address is valid and can be accessed in user mode using
    // the flags PTE_P and PTE_U
    // The entry in the page directory is 32-bit, of which first 20 bits store the physical 
    // address of the page table, the remaining 12 bits stores different flags(such as dirty bit,
    // valid bit, write bit etc)
    if((currentproc_pgdir[i] & PTE_P) && (currentproc_pgdir[i] & PTE_U))
    {
      // PTE_ADDR is a macro which can be used to zero the ending 12 bits, so as to get
      // physical page table address
      // P2V can be used to convert the physical address to virtual address (by adding KERNBASE)
      pte_t* pagetable= (pte_t*)(P2V(PTE_ADDR(currentproc_pgdir[i])));

      // In each page table we go through all 2^10 entries and check for valid pages which
      // can be accessed in user mode in the same way as above
      for(int j=0;j<NPTENTRIES;j++)
      {
        if((pagetable[j]&PTE_P) && (pagetable[j]&PTE_U))
        {
          // Getting virtual page number using the page directory and page table entries
          uint vaddr = (i << 22) + (j << 12);
          uint paddr = PTE_ADDR(pagetable[j]);
          cprintf("pgdir entry Number: %d pgt entry Number : %d Virtual Address: %p Physical Address: %p\n", i, j ,vaddr,paddr );
        }
      }
    }
  }
  return 0;
}